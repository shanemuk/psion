Welcome to StereoVu!
Version 1.01 January 1999
Dr Shane McKee

A whole world of amazing 3D images awaits your occipital cortex with StereoVu, the most advanced stereogram generator yet available for any palmtop computer.

Yes - on your Series 5 you can generate incredible 3D images, just like those Magic Eye� and 5D� images that adorned T-shirts and posters back in 1994.

What's more, you can do it using the familiar Sketch application on your Series 5, and access 4 image planes, to give your stereograms as much complexity as you wish.
INSTALLING StereoVu
1/ Unzip the source file (STEREOVU_S5.ZIP)
2/ Copy all the files into a folder: C:\System\Apps\StereoVu
This is CASE SENSITIVE!!!!! Here are some tips for getting it right:
Go to the "System" view on your Psion Series 5
Navigate to the root folder of whichever disk on which you wish to install StereoVu (eg "C:\" - the internal memory). You do this by moving the cursor as far left as you can, and as far up as you can. If you're presented with a little folder that says "(Close)", press enter, and repeat the process until you've reached the "root folder".
Find the folder called "System", or create one if you can't find it. (Menu > File > Create new > Folder. Call it "System")
Enter the System folder (you may need to press Menu > Tools > Preferences > Show System folder (tick) to be able to view it)
Enter the "Apps" folder (or create it if necessary)
Create a new folder called "StereoVu" (case-sensitive!)
Enter this new folder
Copy all the files from the original ZIP file into this folder

That should be you ready to roll. Press the Extras button on your Psion, and select "StereoVu" from the Extras bar. If it has not appeared, please make sure you have installed it correctly!!! All the files should be in the folder:
	"C:\System\Apps\StereoVu"

If you want to use the example stereograms, create a new folder in your root folder called "StereoVu" (or whatever you like), and copy all the *.mbm files into this folder.

Any mbm file name beginning with "bg_" is a background file, and all the others are template files.

Please consult the enclosed Help file, StereoVu.hlp for further details.
Have fun using StereoVu!

Remember that I have lots of medical software available on:
http://dnausers.d-n-a.net/psionmed

- Shane McKee, Jan 1999
shane@dna1.dnet.co.uk
http://www.d-n-a.net/psionmed