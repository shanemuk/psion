The WARDRND.ZIP file contains all the files
necessary for WardRound. Simply UNZIP it,
and place the files in the following directories:

WARDRND.OPA: \app
wardrnd.txt: \wrd    (Optional)
wardrnd.rsc: \opd    (Optional)
example.pat: \pat    (Optional - patient file)

Any bugs/comments:

shane@dna1.dnet.co.uk

Shane McKee
Clinical Genetics Unit
Birmingham Women's Hospital
Edgbaston
Birmingham UK
B15 2TG
